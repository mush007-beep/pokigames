<?php
// +------------------------------------------------------------------------+
// | @author: coder_mvn
// | @name: Poko - The Arcade Online HTML5 Game Playing Platform
// | @author_email: mvk62015@gmail.com   
// | @version: 4.0v
// +------------------------------------------------------------------------+
// | Poko - The Arcade Online HTML5 Game Playing Platform
// | Copyright (c) 2023 Poko. All rights reserved.
// +------------------------------------------------------------------------+

@header("Location: install/");
die();

// MySQL Database User
define("DB_USERNAME", "root");
// MySQL Database Password
define("DB_PASSWORD", "");
// MySQL Hostname
define("DB_HOST", "localhost");
// MySQL Database Name
define("DB_NAME", "zontal_poko");

// Site URL
$site_url = "http://localhost/poko-for-customer/"; // e.g (http://example.com)
?>